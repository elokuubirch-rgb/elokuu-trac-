package com.footprint.ui.state

import com.footprint.data.model.FootprintEntry
import com.footprint.data.model.FootprintSummary
import com.footprint.data.model.Mood
import com.footprint.data.model.TravelGoal
import com.footprint.ui.screens.art.ArmorType
import com.footprint.ui.screens.art.WoodType
import com.footprint.ui.theme.ThemeMode
import java.time.LocalDate

data class FilterState(
        val selectedMood: Mood? = null,
        val searchQuery: String = "",
        val year: Int = LocalDate.now().year
)

data class FootprintUiState(
        val entries: List<FootprintEntry> = emptyList(),
        val visibleEntries: List<FootprintEntry> = emptyList(),
        val goals: List<TravelGoal> = emptyList(),
        val yearlyEntries: List<FootprintEntry> = emptyList(),
        val yearlyGoals: List<TravelGoal> = emptyList(),
        val summary: FootprintSummary = FootprintSummary(),
        val filterState: FilterState = FilterState(),
        val themeMode: ThemeMode = ThemeMode.SYSTEM,
        val themeStyle: com.footprint.ui.theme.AppThemeStyle =
                com.footprint.ui.theme.AppThemeStyle.CLASSIC,
        val userNickname: String = "旅行者",
        val userAvatarId: String = "avatar_1",
        val blurStrength: Float = 16f,
        val hapticFeedbackEnabled: Boolean = true,
        val artAuthorName: String = "漂泊的灵魂",
        val artFontName: String = "Default",
        val artColorStyle: String = "Neon Green",
        val artTextColor: String = "White",
        val artTextItalic: Boolean = false,
        val artTextBorder: Boolean = false,
        val polaroidFrameStyle: String = "CLASSIC_WHITE",
        val polaroidFramePadding: Float = 0.5f,
        val polaroidInnerBorder: Float = 1f,
        val woodType: WoodType = WoodType.ASH,
        val engravingDepth: Float = 0.5f,
        val canvasGrain: Float = 0.3f,
        val armorType: ArmorType = ArmorType.GUNMETAL,
        val mechanicalSeams: Float = 0.5f,
        val hasHazardStriping: Boolean = false,
        val randomMemory: FootprintEntry? = null,
        val memoryQuote: String? = null,
        val isLoading: Boolean = true
)
