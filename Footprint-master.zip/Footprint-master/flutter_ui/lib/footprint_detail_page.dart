import 'dart:io';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'main.dart';

class FootprintDetailPage extends StatefulWidget {
  final dynamic entry;
  const FootprintDetailPage({super.key, this.entry});

  @override
  State<FootprintDetailPage> createState() => _FootprintDetailPageState();
}

class _FootprintDetailPageState extends State<FootprintDetailPage> {
  late Map<String, dynamic> entry;
  List<Map<String, double>> trackPoints = [];
  MethodChannel? _mapChannel;

  late String title;
  late String location;
  late String date;
  late String mood;
  late Color moodColor;
  late String weather;
  late String detail;
  late double distance;
  late int energy;
  late List<String> photos;
  late String travelMode;
  late IconData travelIcon;

  @override
  void initState() {
    super.initState();
    entry = widget.entry != null ? Map<String, dynamic>.from(widget.entry!) : {};

    if (entry['happenedOn'] != null) {
      _loadTrackPoints(entry['happenedOn']);
    }

    title = entry['title'] ?? "未命名足迹";
    location = entry['location'] ?? "未知地点";

    // Format location if it looks like raw coordinates
    final coordRegex = RegExp(r'(-?\d+\.\d+)\s*,\s*(-?\d+\.\d+)');
    final match = coordRegex.firstMatch(location);
    if (match != null) {
      try {
        double lat = double.parse(match.group(1)!);
        double lng = double.parse(match.group(2)!);
        location = "${lat.toStringAsFixed(3)}, ${lng.toStringAsFixed(3)}";
      } catch (_) {}
    }

    date = entry['happenedOn'] ?? "未知日期";
    
    String rawMood = entry['mood'] ?? "";
    mood = _mapMoodToChinese(rawMood);
    moodColor = _getMoodColor(rawMood);
    
    weather = entry['weather'] ?? "-";
    detail = entry['detail'] ?? entry['notes'] ?? "没有记录详细内容。";
    distance = (entry['distanceKm'] as num?)?.toDouble() ?? 0.0;
    energy = (entry['energyLevel'] as num?)?.toInt() ?? 0;
    
    // Parse photos if it's a list or comma-separated string
    final rawPhotos = entry['photos'];
    if (rawPhotos is List) {
      photos = rawPhotos.map((e) => e.toString()).toList();
    } else if (rawPhotos is String && rawPhotos.isNotEmpty) {
      photos = rawPhotos.split(',').map((s) => s.trim()).toList();
    } else {
      photos = [];
    }

    final t = entry['transportType'] ?? entry['transportMethod'] ?? "UNKNOWN";
    switch(t) {
      case "WALK": travelMode = "步行"; travelIcon = Icons.directions_walk; break;
      case "BIKE": travelMode = "骑行"; travelIcon = Icons.directions_bike; break;
      case "CAR": travelMode = "自驾"; travelIcon = Icons.directions_car; break;
      case "TRAIN": travelMode = "铁路"; travelIcon = Icons.train; break;
      case "PLANE": travelMode = "航空"; travelIcon = Icons.flight; break;
      default: travelMode = "未知"; travelIcon = Icons.help_outline;
    }
  }

  Future<void> _loadTrackPoints(String dateStr) async {
    try {
      final date = DateTime.parse(dateStr);
      final startTime = DateTime.utc(date.year, date.month, date.day).millisecondsSinceEpoch;
      final endTime = startTime + 86400000;
      final result = await const MethodChannel('com.footprint/data')
          .invokeMethod('getTrackPoints', {'startTime': startTime, 'endTime': endTime});
      if (result != null) {
        final List<dynamic> list = jsonDecode(result);
        if (mounted) {
          setState(() {
            trackPoints = list.map((p) => {
              'lat': p['latitude'] as double,
              'lng': p['longitude'] as double
            }).toList();
          });
          if (_mapChannel != null && trackPoints.isNotEmpty) {
             _mapChannel?.invokeMethod('setTrackingPath', trackPoints);
             _mapChannel?.invokeMethod('centerLocation', {
               'latitude': trackPoints.first['lat'],
               'longitude': trackPoints.first['lng'],
               'zoom': 15.0
             });
          }
        }
      }
    } catch (e) {
      debugPrint("Load track points fail: $e");
    }
  }

  String _mapMoodToChinese(String englishMood) {
    if (englishMood.contains(RegExp(r'[\u4e00-\u9fa5]'))) return englishMood;
    switch (englishMood.toUpperCase()) {
      case "EXCITED": return "激情";
      case "CURIOUS": return "探索";
      case "RELAXED": return "放松";
      case "REFLECTIVE": return "思考";
      case "HAPPY": return "愉快";
      case "CALM": return "平静";
      default: return englishMood.isEmpty ? "平静" : englishMood;
    }
  }

  Color _getMoodColor(String englishMood) {
    switch (englishMood.toUpperCase()) {
      case "EXCITED": return Colors.orange;
      case "CURIOUS": return Colors.teal;
      case "RELAXED": return Colors.blue;
      case "REFLECTIVE": return Colors.purple;
      case "HAPPY": return Colors.orange;
      case "CALM": return Colors.blue;
      default: return Colors.blueGrey;
    }
  }

  int? selectedPhotoIndex;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        children: [
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.white.withOpacity(0.68),
                    kAtelierCanvas,
                    const Color(0xFFEDE2D7),
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            top: -110,
            right: -90,
            child: Container(
              width: 250,
              height: 250,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: moodColor.withOpacity(0.14),
              ),
            ),
          ),
          CustomScrollView(
            slivers: [
              SliverAppBar(
                expandedHeight: 300,
                pinned: true,
                backgroundColor: Colors.transparent,
                iconTheme: IconThemeData(color: cs.onSurface),
                actions: [
                  IconButton(
                    icon: const Icon(Icons.edit),
                    onPressed: () async {
                      final result = await Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => AddFootprintPage(initialEntry: widget.entry),
                        ),
                      );
                      if (result == true) {
                        Navigator.pop(context, true); // Pop to list and refresh
                      }
                    },
                  ),
                ],
                flexibleSpace: FlexibleSpaceBar(
                  background: Stack(
                    fit: StackFit.expand,
                    children: [
                      // Hero background image or color
                      Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Color.alphaBlend(Colors.white.withOpacity(0.18), moodColor.withOpacity(0.72)),
                              moodColor.withOpacity(0.24),
                            ],
                          ),
                          borderRadius: const BorderRadius.vertical(
                            bottom: Radius.circular(36),
                          ),
                        ),
                      ),
                      // Gradient overlay
                      Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Colors.transparent,
                              kAtelierCanvas,
                            ],
                          ),
                        ),
                      ),
                      // Text overlay
                      Positioned(
                        left: 24,
                        bottom: 24,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: moodColor.withOpacity(0.2),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(mood, style: tt.labelMedium?.copyWith(color: moodColor)),
                            ),
                            const SizedBox(height: 8),
                            Text(title, style: tt.headlineLarge?.copyWith(fontWeight: FontWeight.w900, color: cs.onSurface)),
                            Row(
                              children: [
                                Icon(Icons.location_on, size: 16, color: cs.primary),
                                const SizedBox(width: 4),
                                Text(location, style: tt.bodyMedium?.copyWith(color: cs.primary)),
                                Padding(
                                  padding: const EdgeInsets.symmetric(horizontal: 8),
                                  child: Text("•", style: TextStyle(color: cs.outline)),
                                ),
                                Text(date, style: tt.bodyMedium?.copyWith(color: cs.outline)),
                              ],
                            ),
                            const SizedBox(height: 12),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                              decoration: BoxDecoration(
                                color: cs.primaryContainer.withOpacity(0.15),
                                borderRadius: BorderRadius.circular(16),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(Icons.wb_sunny, size: 20, color: Colors.orange), // hologram placeholder
                                  const SizedBox(width: 8),
                                  Text(_mapWeatherToChinese(weather), style: tt.labelLarge?.copyWith(color: Colors.orange)),
                                  const SizedBox(width: 8),
                                  Text("•", style: TextStyle(color: Colors.orange.withOpacity(0.5))),
                                  const SizedBox(width: 8),
                                  Text(date, style: tt.labelLarge?.copyWith(color: Colors.orange)),
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SliverList(
                delegate: SliverChildListDelegate([
                  // Stats row
                  Padding(
                    padding: const EdgeInsets.only(top: 24, bottom: 24, left: 16, right: 16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _statDrop("里程", "${distance.toStringAsFixed(1)} KM", travelIcon, cs, tt),
                        _statDrop("出行", travelMode, travelIcon, cs, tt),
                        _statDrop("能量", "$energy", Icons.bolt, cs, tt),
                        _statDrop("心情", mood, Icons.mood, cs, tt),
                      ],
                    ),
                  ),

                  // Detail Body
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: Text(
                      detail,
                      style: tt.bodyLarge?.copyWith(
                        height: 1.8,
                        letterSpacing: 0.5,
                        color: cs.onSurfaceVariant,
                      ),
                    ),
                  ),
                  
                  // Gallery
                  if (photos.isNotEmpty) ...[
                    const SizedBox(height: 32),
                    Padding(
                      padding: const EdgeInsets.only(left: 24, bottom: 12),
                      child: Text("瞬间", style: tt.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
                    ),
                    SizedBox(
                      height: 200,
                      child: ListView.separated(
                        padding: const EdgeInsets.symmetric(horizontal: 24),
                        scrollDirection: Axis.horizontal,
                        itemCount: photos.length,
                        separatorBuilder: (context, index) => const SizedBox(width: 12),
                        itemBuilder: (context, index) {
                          final photoPath = photos[index];
                          final file = File(photoPath);
                          return GestureDetector(
                            onTap: () => _showFullImage(context, photoPath),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(16),
                              child: file.existsSync()
                                ? Image.file(file, width: 150, height: 200, fit: BoxFit.cover,
                                    errorBuilder: (_, __, ___) => _photoPlaceholder(cs))
                                : _photoPlaceholder(cs),
                            ),
                          );
                        },
                      ),
                    ),
                  ],

                  const SizedBox(height: 32),
                  Padding(
                    padding: const EdgeInsets.only(left: 24, bottom: 12),
                    child: Text("足迹轨迹", style: tt.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: Container(
                      height: 250,
                      decoration: BoxDecoration(
                        color: cs.surfaceContainerHighest,
                        borderRadius: BorderRadius.circular(24),
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(24),
                        child: AndroidView(
                          viewType: 'com.footprint/amap',
                          gestureRecognizers: <Factory<OneSequenceGestureRecognizer>>{
                            Factory<OneSequenceGestureRecognizer>(() => EagerGestureRecognizer()),
                          },
                          onPlatformViewCreated: (id) {
                            _mapChannel = MethodChannel('com.footprint/amap_$id');
                            if (trackPoints.isNotEmpty) {
                               _mapChannel?.invokeMethod('setTrackingPath', trackPoints);
                               _mapChannel?.invokeMethod('centerLocation', {
                                  'latitude': trackPoints.first['lat'],
                                  'longitude': trackPoints.first['lng'],
                                  'zoom': 15.0
                               });
                            }
                          },
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 48),
                ]),
              ),
            ],
          ),
        ],
      ),
    );
  }

  String _mapWeatherToChinese(String englishWeather) {
    if (englishWeather.contains(RegExp(r'[\u4e00-\u9fa5]'))) return englishWeather;
    final w = (englishWeather).toUpperCase();
    if (w.contains("SUNNY")) return "晴天";
    if (w.contains("CLOUDY")) return "多云";
    if (w.contains("RAIN")) return "雨天";
    if (w.contains("SNOW")) return "雪天";
    if (w.contains("WIND")) return "大风";
    if (w.contains("MIST") || w.contains("FOG")) return "薄雾";
    if (w.contains("PARTLY")) return "晴间多云";
    if (w.contains("THUNDER")) return "雷阵雨";
    return englishWeather;
  }

  Widget _statDrop(String label, String value, IconData icon, ColorScheme cs, TextTheme tt) {
    return Column(
      children: [
        Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            color: cs.surfaceContainerHighest,
            shape: BoxShape.circle,
          ),
          child: Icon(icon, color: cs.primary),
        ),
        const SizedBox(height: 8),
        Text(value, style: tt.bodyMedium?.copyWith(fontWeight: FontWeight.bold)),
        Text(label, style: tt.labelSmall?.copyWith(color: cs.outline)),
      ],
    );
  }
  Widget _photoPlaceholder(ColorScheme cs) {
    return Container(
      width: 150, height: 200,
      decoration: BoxDecoration(color: cs.surfaceContainerHighest, borderRadius: BorderRadius.circular(16)),
      child: const Center(child: Icon(Icons.broken_image, size: 48, color: Colors.grey)),
    );
  }

  void _showFullImage(BuildContext context, String path) {
    final file = File(path);
    if (!file.existsSync()) return;
    showDialog(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.all(16),
        child: GestureDetector(
          onTap: () => Navigator.pop(ctx),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: Image.file(file, fit: BoxFit.contain),
          ),
        ),
      ),
    );
  }
}
